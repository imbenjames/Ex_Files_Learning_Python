#
# Example file for HelloWorld
#

def main():
  print ("hello world!")
    
if __name__ == "__main__":
  main()
